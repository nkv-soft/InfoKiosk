
import java.sql.*;


public class sqltest {
	public static String lolen(String query){
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String desc=null;
		String name = null;
			try
				{
				// Load the JDBC driver
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					String connectionUrl = "jdbc:mysql://83.212.XX.XX:3306/softeng";
					String connectionUser = "XXX";
					String connectionPassword = "XXXX";
					conn = DriverManager.getConnection(connectionUrl, connectionUser,connectionPassword);
					stmt = conn.createStatement();
					rs = stmt.executeQuery(query);
					
					while(rs.next()){
						name = rs.getString("name");
						desc = rs.getString("description");
					}
					//System.out.println(desc);
					conn.close();
				
					
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			if(name == null){
				return "1Nothing found";
			}
			return "0" + name.substring(0,4) + desc;
	}
}