import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

import javax.imageio.ImageIO;
import java.io.File;
import java.awt.image.BufferedImage;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseMotionAdapter;

import java.io.*;



public class GUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	 


	public GUI() {
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		
		
		
		final JLabel label_1 = new JLabel("<html>\u039A\u03B1\u03BB\u03CE\u03C2 \u03AE\u03C1\u03B8\u03B1\u03C4\u03B5 \u03C3\u03C4\u03BF \u039C\u03BF\u03C5\u03C3\u03B5\u03AF\u03BF \u03A4\u03B5\u03C7\u03BD\u03BF\u03BB\u03BF\u03B3\u03B9\u03BA\u03AE\u03C2 \u0399\u03C3\u03C4\u03BF\u03C1\u03AF\u03B1\u03C2 \u03C4\u03BF\u03C5 \u0391\u03A4\u0395\u0399 \u03A0\u03B5\u03B9\u03C1\u03B1\u03B9\u03AC. \u0393\u03B9\u03B1 \u03BD\u03B1 \u03B4\u03B5\u03AF\u03C4\u03B5 \u03C0\u03BF\u03C5 \u03B2\u03C1\u03AF\u03C3\u03BA\u03B5\u03C3\u03C4\u03B5 \u03C0\u03B1\u03C4\u03AE\u03C3\u03C4\u03B5 \u03C4\u03BF \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF \"\u03A7\u03AC\u03C1\u03C4\u03B7\u03C2\". \u0393\u03B9\u03B1 \u03BD\u03B1 \u03B1\u03BD\u03B1\u03B6\u03B7\u03C4\u03AE\u03C3\u03B5\u03C4\u03B5 \u03C0\u03BB\u03B7\u03C1\u03BF\u03C6\u03BF\u03C1\u03AF\u03B5\u03C2 \u03B3\u03B9\u03B1 \u03BA\u03AC\u03C0\u03BF\u03B9\u03BF \u03AD\u03BA\u03B8\u03B5\u03BC\u03B1 \u03C0\u03BB\u03B7\u03BA\u03C4\u03C1\u03BF\u03BB\u03BF\u03B3\u03AE\u03C3\u03C4\u03B5 \u03C3\u03C4\u03B7 \u03B3\u03C1\u03B1\u03BC\u03BC\u03AE \u03B1\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C2 \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C4\u03AE\u03C3\u03C4\u03B5 \u03C4\u03BF \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF \"\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7\". \u03A4\u03AD\u03BB\u03BF\u03C2 \u03B3\u03B9\u03B1 \u03BD\u03B1 \u03B1\u03BB\u03BB\u03AC\u03BE\u03B5\u03C4\u03B5 \u03B3\u03BB\u03CE\u03C3\u03C3\u03B1 \u03B5\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03BA\u03AC\u03C0\u03BF\u03B9\u03B1 \u03AC\u03BB\u03BB\u03B7 \u03B1\u03C0\u03CC \u03C4\u03B1 \u03B5\u03B9\u03BA\u03BF\u03BD\u03AF\u03B4\u03B9\u03B1 \u03BA\u03AC\u03C4\u03C9 \u03B1\u03C1\u03B9\u03C3\u03C4\u03B5\u03C1\u03AC.</html>");
		label_1.setBounds(444, 28, 530, 436);
		contentPane.add(label_1);
		int lang = 1;
		int secret = 0;
		
		final JLabel label = new JLabel(new ImageIcon(getClass().getResource("mus.jpg")));
		label.setBounds(10, 28, 422, 422);
		getContentPane().add( label );
		
	
		final JButton btnSearch = new JButton("\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String search_query = txtSearch.getText();
				String returned_results = sqltest.lolen("select * from old_pc where search_terms like '%" + search_query + "%'");
				if( returned_results.subSequence(0, 1).equals("0") ){
					label_1.setText("<html>" + returned_results.substring(5) + "</html>");
					label.setIcon(new ImageIcon(getClass().getResource( returned_results.substring(1, 5) + ".jpg")));
				}
				else{
					label_1.setText("<html>" + returned_results.substring(1) + "</html>");
				}
				
			}
		});
		btnSearch.setBounds(868, 481, 106, 23);
		contentPane.add(btnSearch);
		
		
		
		txtSearch = new JTextField();
		txtSearch.setText("\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7");
		txtSearch.setBounds(454, 481, 404, 23);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		
		

		
		
		final JLabel label_2 = new JLabel("");
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				label_1.setText("<html>Welcome to the Technologial Museum of History of ATEI PEIRAIA. </html>");
				txtSearch.setText("Search");
				btnSearch.setText("Search");
				label.setIcon(new ImageIcon(getClass().getResource("mus.jpg")));
			}
		});
		label_2.setIcon(new ImageIcon(getClass().getResource("uk-flag.jpg")));
		label_2.setBounds(10, 484, 31, 23);
		contentPane.add(label_2);
		
		
		
		
		final JLabel lblmap = new JLabel("");
		lblmap.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Diavazoume ena arxeio pou se ka8e infokiosk einai diaforetiko gia na 3eroume poia eikona tou xarth na dei3oume
				String content=null;
				/*URL test = getClass.getResourceAsStream("id.txt");
				try (FileReader reader = new FileReader("../../../resources/id.txt")) {
				    char[] chars =new char[(int) 100];
				    reader.read(chars);
				    content = new String(chars);
				} catch (IOException q) {
				    q.printStackTrace();
				}
				*/
				 InputStream in = GUI.class.getResourceAsStream("id.txt");
				    try {
				        BufferedReader reader=new BufferedReader(new InputStreamReader(in));
				        String line=null;
				            while((line=reader.readLine())!=null){
				                content=line;
				            }
				    } catch (Exception q) {
				        // TODO Auto-generated catch block
				        q.printStackTrace();
				    }
				label.setIcon(new ImageIcon(getClass().getResource( content.substring(0, 1) + ".png")));
				
			}
		});
		lblmap.setIcon(new ImageIcon(getClass().getResource("map.png")));
		lblmap.setBounds(117, 481, 32, 32);
		contentPane.add(lblmap);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtSearch.setText("\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7");
				label_1.setText("<html>\u039A\u03B1\u03BB\u03CE\u03C2 \u03AE\u03C1\u03B8\u03B1\u03C4\u03B5 \u03C3\u03C4\u03BF \u039C\u03BF\u03C5\u03C3\u03B5\u03AF\u03BF \u03A4\u03B5\u03C7\u03BD\u03BF\u03BB\u03BF\u03B3\u03B9\u03BA\u03AE\u03C2 \u0399\u03C3\u03C4\u03BF\u03C1\u03AF\u03B1\u03C2 \u03C4\u03BF\u03C5 \u0391\u03A4\u0395\u0399 \u03A0\u03B5\u03B9\u03C1\u03B1\u03B9\u03AC. \u0393\u03B9\u03B1 \u03BD\u03B1 \u03B4\u03B5\u03AF\u03C4\u03B5 \u03C0\u03BF\u03C5 \u03B2\u03C1\u03AF\u03C3\u03BA\u03B5\u03C3\u03C4\u03B5 \u03C0\u03B1\u03C4\u03AE\u03C3\u03C4\u03B5 \u03C4\u03BF \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF \"\u03A7\u03AC\u03C1\u03C4\u03B7\u03C2\". \u0393\u03B9\u03B1 \u03BD\u03B1 \u03B1\u03BD\u03B1\u03B6\u03B7\u03C4\u03AE\u03C3\u03B5\u03C4\u03B5 \u03C0\u03BB\u03B7\u03C1\u03BF\u03C6\u03BF\u03C1\u03AF\u03B5\u03C2 \u03B3\u03B9\u03B1 \u03BA\u03AC\u03C0\u03BF\u03B9\u03BF \u03AD\u03BA\u03B8\u03B5\u03BC\u03B1 \u03C0\u03BB\u03B7\u03BA\u03C4\u03C1\u03BF\u03BB\u03BF\u03B3\u03AE\u03C3\u03C4\u03B5 \u03C3\u03C4\u03B7 \u03B3\u03C1\u03B1\u03BC\u03BC\u03AE \u03B1\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C2 \u03BA\u03B1\u03B9 \u03C0\u03B1\u03C4\u03AE\u03C3\u03C4\u03B5 \u03C4\u03BF \u03BA\u03BF\u03C5\u03BC\u03C0\u03AF \"\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7\". \u03A4\u03AD\u03BB\u03BF\u03C2 \u03B3\u03B9\u03B1 \u03BD\u03B1 \u03B1\u03BB\u03BB\u03AC\u03BE\u03B5\u03C4\u03B5 \u03B3\u03BB\u03CE\u03C3\u03C3\u03B1 \u03B5\u03C0\u03B9\u03BB\u03AD\u03BE\u03C4\u03B5 \u03BA\u03AC\u03C0\u03BF\u03B9\u03B1 \u03AC\u03BB\u03BB\u03B7 \u03B1\u03C0\u03CC \u03C4\u03B1 \u03B5\u03B9\u03BA\u03BF\u03BD\u03AF\u03B4\u03B9\u03B1 \u03BA\u03AC\u03C4\u03C9 \u03B1\u03C1\u03B9\u03C3\u03C4\u03B5\u03C1\u03AC.</html>");
				btnSearch.setText("\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7");
				label.setIcon(new ImageIcon(getClass().getResource("mus.jpg")));
			}
		});
		lblNewLabel.setIcon(new ImageIcon(getClass().getResource("greek.jpg")));
		lblNewLabel.setBounds(60, 484, 31, 23);
		contentPane.add(lblNewLabel);
		
		
		//Aorato Jlabel gia thn eisodo twn diaxeiristwn, 8ewritika otan kaneis click me to mouse kai drag 8a emfanizei ena para8uro gia eisagwgh stoixeiwn
		//gia eisodo sto Admin panel
		JLabel hiddenlogin = new JLabel("");
		hiddenlogin.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
				System.out.println("Edw 8a htan elegxos twn stoixeiwn kanonika");
			}
		});
		hiddenlogin.setBounds(267, 461, 96, 69);
		contentPane.add(hiddenlogin);
		
		

	}
}
