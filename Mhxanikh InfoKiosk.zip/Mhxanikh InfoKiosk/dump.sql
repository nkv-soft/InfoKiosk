-- MySQL dump 10.13  Distrib 5.1.66, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: softeng
-- ------------------------------------------------------
-- Server version	5.1.66-0+squeeze1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `old_pc`
--

DROP TABLE IF EXISTS `old_pc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_pc` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` longtext,
  `search_terms` longtext
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_pc`
--

LOCK TABLES `old_pc` WRITE;
/*!40000 ALTER TABLE `old_pc` DISABLE KEYS */;
INSERT INTO `old_pc` VALUES (1,'Eniac','ENIAC (pron.: /\'ini.æk/ or /\'?ni.æk/; Electronic Numerical Integrator And Computer)[1][2] was the first electronic general-purpose computer. It was Turing-complete, digital, and capable of being reprogrammed to solve a full range of computing problems.[3]\n\nENIAC was designed to calculate artillery firing tables for the United States Army\'s Ballistic Research Laboratory.[4][5] When ENIAC was announced in 1946 it was heralded in the press as a Giant Brain.[6] It had a speed of one thousand times that of electro-mechanical machines. This mathematical power, coupled with general-purpose programmability, excited scientists and industrialists. The inventors promoted the spread of these new ideas by conducting a series of lectures on computer architecture.\n\nENIAC\'s design and construction was financed by the United States Army during World War II. The construction contract was signed on June 5, 1943, and work on the computer began in secret by the University of Pennsylvania\'s Moore School of Electrical Engineering starting the following month under the code name Project PX. The completed machine was announced to the public the evening of February 14, 1946[7] and formally dedicated the next day[8] at the University of Pennsylvania, having cost almost $500,000 (approximately $6,000,000 today). It was formally accepted by the U.S. Army Ordnance Corps in July 1946. ENIAC was shut down on November 9, 1946 for a refurbishment and a memory upgrade, and was transferred to Aberdeen Proving Ground, Maryland in 1947. There, on July 29, 1947, it was turned on and was in continuous operation until 11:45 p.m. on October 2, 1955.[2]\n\nENIAC was conceived and designed by John Mauchly and J. Presper Eckert of the University of Pennsylvania.[9] The team of design engineers assisting the development included Robert F. Shaw (function tables), Jeffrey Chuan Chu (divider/square-rooter), Thomas Kite Sharpless (master programmer), Arthur Burks (multiplier), Harry Huskey (reader/printer) and Jack Davis (accumulators). ENIAC was named an IEEE Milestone in 1987.[10]','eniac 1946 U.S.'),(2,'deep_blue','Deep Blue was a chess-playing computer developed by IBM. On May 11, 1997, the machine, with human intervention between games, won the second six-game match against world champion Garry Kasparov by two wins to one with three draws.[1] Kasparov accused IBM of cheating and demanded a rematch, but IBM refused and dismantled Deep Blue.[2] Kasparov had beaten a previous version of Deep Blue in 1996.\nThe project was started as ChipTest at Carnegie Mellon University by Feng-hsiung Hsu, followed by its successor, Deep Thought. After their graduation from Carnegie Mellon, Hsu, Thomas Anantharaman, and Murray Campbell from the Deep Thought team were hired by IBM Research to continue their quest to build a chess machine that could defeat the world champion.[3] Hsu and Campbell joined IBM in autumn 1989, with Anantharaman following later.[4] Anantharaman subsequently left IBM for Wall Street and Arthur Joseph Hoane joined the team to perform programming tasks.[5] Jerry Brody, a long-time employee of IBM Research, was recruited for the team in 1990.[6] The team was managed first by Randy Moulic, followed by Chung-Jen (C J) Tan.[7]\n\nAfter Deep Thought\'s 1989 match against Kasparov, IBM held a contest to rename the chess machine and it became Deep Blue, a play on IBM\'s nickname, Big Blue.[8] After a scaled down version of Deep Blue, Deep Blue Jr., played Grandmaster Joel Benjamin, Hsu and Campbell decided that Benjamin was the expert they were looking for to develop Deep Blue\'s opening book, and Benjamin was signed by IBM Research to assist with the preparations for Deep Blue\'s matches against Garry Kasparov.[9]\n\nIn 1995 Deep Blue prototype (actually Deep Thought II, renamed for PR reasons) played in the 8th World Computer Chess Championship. Deep Blue prototype played the computer program Wchess to a draw while Wchess was running on a personal computer. In round 5 Deep Blue prototype had the white pieces and lost to the computer program Fritz 3 in 39 moves while Fritz was running on an Intel Pentium 90Mhz personal computer. In the end of the championship Deep Blue prototype was tied for second place with the computer program Junior while Junior was running on a personal computer.[10]','deep blue chess'),(3,'enigma','An Enigma machine is any of a family of related electro-mechanical rotor cipher machines used for the encryption and decryption of secret messages. Enigma was invented by the German engineer Arthur Scherbius at the end of World War I.[1] The early models were used commercially from the early 1920s, and adopted by military and government services of several countries . most notably by Nazi Germany before and during World War II.[2] Several different Enigma models were produced, but the German military models are the ones most commonly discussed.\n\nThe Polish Cipher Bureau first broke Germany\'s military Enigma ciphers in December 1932. Five weeks before the outbreak of World War II, on 25 July 1939, they presented their Enigma-decryption techniques and equipment to French and British military intelligence in Warsaw.[3][4][5] From 1938 onwards, additional complexity was repeatedly added to the machines, making the initial decryption techniques increasingly unsuccessful. Nonetheless, the Polish breakthrough represented a vital basis for the later British effort.[6] During the war, British codebreakers were able to decrypt a vast number of messages that had been enciphered using the Enigma. The intelligence gleaned from this source, codenamed Ultra by the British, was a substantial aid to the Allied war effort.[7]\n\nThe exact influence of Ultra on the course of the war is debated; an oft-repeated assessment is that decryption of German ciphers hastened the end of the European war by two years.[8][9][10] Winston Churchill told the United Kingdom\'s King George VI after World War II: It was thanks to Ultra that we won the war.[11]\n\nAlthough Enigma had some cryptographic weaknesses, in practice it was only in combination with procedural flaws, operator mistakes, captured key tables and hardware that Allied cryptanalysts were able to be so successful.','enigma cryptography war');
/*!40000 ALTER TABLE `old_pc` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-02-18 15:23:07
